

#import <UIKit/UIKit.h>

@interface PukeView : UIView

- (instancetype)initWithFrame:(CGRect)frame TuPianMing:(NSString *)TuPianMing;

- (void)ShanChuBgPuKe;

- (void)ShanChuKaPai;

- (void)TianJiaKaPai:(NSString *)KaPaiMing;

@end
