
#import <UIKit/UIKit.h>

@interface SingleViewController : UIViewController

- (void)addSingleItem:(int)WanJiaHaoMa bankerNum:(int)ZhuangJiaHaoMa;

@end
