
#import "PuKeUtils.h"

@implementation PuKeUtils

+ (NSDictionary *)DeDaoPuKeZiDian
{
    NSDictionary *dic = @{@"a1.jpg":@"1",
                          @"a2.jpg":@"2",
                          @"a3.jpg":@"3",
                          @"a4.jpg":@"4",
                          @"a5.jpg":@"5",
                          @"a6.jpg":@"6",
                          @"a7.jpg":@"7",
                          @"a8.jpg":@"8",
                          @"a9.jpg":@"9",
                          @"a10.jpg":@"10",
                          @"a11.jpg":@"11",
                          @"a12.jpg":@"12",
                          @"a13.jpg":@"13",
                          @"b1.jpg":@"1",
                          @"b2.jpg":@"2",
                          @"b3.jpg":@"3",
                          @"b4.jpg":@"4",
                          @"b5.jpg":@"5",
                          @"b6.jpg":@"6",
                          @"b7.jpg":@"7",
                          @"b8.jpg":@"8",
                          @"b9.jpg":@"9",
                          @"b10.jpg":@"10",
                          @"b11.jpg":@"11",
                          @"b12.jpg":@"12",
                          @"b13.jpg":@"13",
                          @"c1.jpg":@"1",
                          @"c2.jpg":@"2",
                          @"c3.jpg":@"3",
                          @"c4.jpg":@"4",
                          @"c5.jpg":@"5",
                          @"c6.jpg":@"6",
                          @"c7.jpg":@"7",
                          @"c8.jpg":@"8",
                          @"c9.jpg":@"9",
                          @"c10.jpg":@"10",
                          @"c11.jpg":@"11",
                          @"c12.jpg":@"12",
                          @"c13.jpg":@"13",
                          @"d1.jpg":@"1",
                          @"d2.jpg":@"2",
                          @"d3.jpg":@"3",
                          @"d4.jpg":@"4",
                          @"d5.jpg":@"5",
                          @"d6.jpg":@"6",
                          @"d7.jpg":@"7",
                          @"d8.jpg":@"8",
                          @"d9.jpg":@"9",
                          @"d10.jpg":@"10",
                          @"d11.jpg":@"11",
                          @"d12.jpg":@"12",
                          @"d13.jpg":@"13"};
    return dic;
}

+ (NSArray *)DeDaoSuiJiPuKeShuZuDeShuLiang:(int)ShuLiang
{
    NSArray *PuKeArray = [[[self class] DeDaoPuKeZiDian] allKeys];
    //随机数从这里边产生
    NSMutableArray *startArray = [[NSMutableArray alloc] initWithArray:PuKeArray];
    //随机数产生结果
    NSMutableArray *resultArray = [[NSMutableArray alloc] initWithCapacity:0];
    //随机数个数
    for (int i=0; i<ShuLiang; i++) {
        int t = arc4random()%startArray.count;
        resultArray[i] = startArray[t];
        startArray [t] = [startArray lastObject]; //为更好的乱序，故交换下位置
        [startArray removeLastObject];
    }
    return resultArray;
}

@end
