
#import <Foundation/Foundation.h>

@interface PuKeUtils : NSObject

+ (NSDictionary *)DeDaoPuKeZiDian;

+ (NSArray *)DeDaoSuiJiPuKeShuZuDeShuLiang:(int)ShuLiang;

@end
