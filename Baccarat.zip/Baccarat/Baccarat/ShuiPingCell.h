

#import <UIKit/UIKit.h>

@interface ShuiPingCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *JieGuoTuPian;

- (void)SheZhiTuPianShiTu:(NSString *)TuPianMing;

@end
