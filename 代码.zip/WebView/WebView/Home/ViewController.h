//
//  ViewController.h
//  WebView
//
//  Created by iMac on 2018/1/24.
//  Copyright © 2018年 潴潴侠. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *chooseImageView_1;
@property (weak, nonatomic) IBOutlet UIImageView *chooseImageView_2;

@end

