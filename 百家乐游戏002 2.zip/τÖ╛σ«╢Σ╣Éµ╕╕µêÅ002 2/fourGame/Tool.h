//
//  Tool.h
//  card
//
//  Created by rmbp840 on 17/3/4.
//  Copyright © 2017年 rmbp840. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tool : NSObject
+ (void)play:(NSString *)name;
@end
