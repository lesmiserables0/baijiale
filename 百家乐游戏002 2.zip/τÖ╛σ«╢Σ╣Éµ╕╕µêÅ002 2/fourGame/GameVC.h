

#import <UIKit/UIKit.h>

@interface GameVC : UIViewController

@end
