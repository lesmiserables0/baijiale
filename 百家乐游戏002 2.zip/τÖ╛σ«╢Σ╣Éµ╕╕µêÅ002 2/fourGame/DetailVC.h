//
//  DetailVC.h
//  fourGame
//
//  Created by rmbp840 on 17/4/3.
//  Copyright © 2017年 rmbp840. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailVC : UIViewController

@end
